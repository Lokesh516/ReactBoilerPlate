import React from 'react';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import { store } from '@/store';
import { ThemeProvider } from './ThemeProvider';
import ErrorBoundary from './ErrorBoundary';

interface AppProviderProps {
    children: React.ReactNode;
}

export const AppProvider: React.FC<AppProviderProps> = ({ children }) => {
    return (
        <ErrorBoundary>
            <Provider store={store}>
                <ThemeProvider>
                    <BrowserRouter>
                        {children}
                    </BrowserRouter>
                </ThemeProvider>
            </Provider>
        </ErrorBoundary>
    );
};
